require_relative '../commands/commands'
require_relative 'user_store'
require_relative 'message_dispatch'
require_relative 'postback_dispatch'
require_relative 'bot_profile'
#require_relative 'persistent_menu'
# Require all files here
module Rubotnik; end
