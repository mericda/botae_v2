class Log < ActiveRecord::Base
    
end
