class Response < ActiveRecord::Base

end
